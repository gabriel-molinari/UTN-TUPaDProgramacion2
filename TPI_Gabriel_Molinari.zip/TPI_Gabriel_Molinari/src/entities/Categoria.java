/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

//----------IMPORTS----------
import base.Base;
import java.util.Objects;

/*
    EXPLICACION DE CLASE

    REPRESENTA UNA CATEGORIA DE PRODUCTOS
    DENTRO DEL SISTEMA.
*/

public class Categoria extends Base {
    
    // NOMBRE DE LA CATEGORIA
    private String nombre;

    // DESCRIPCION DE LA CATEGORIA
    private String descripcion;

    // CONSTRUCTOR VACIO
    public Categoria() {
        super();
    }

    // CONSTRUCTOR CON PARAMETROS
    public Categoria(String nombre, String descripcion) {

        // LLAMO AL CONSTRUCTOR PADRE
        super();

        // ASIGNO NOMBRE
        setNombre(nombre);

        // ASIGNO DESCRIPCION
        setDescripcion(descripcion);
    }

    // OBTENGO EL NOMBRE
    public String getNombre() {
        return nombre;
    }

    // ASIGNO EL NOMBRE
    public void setNombre(String nombre) {

        // VALIDO QUE EL NOMBRE NO ESTE VACIO
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }

        this.nombre = nombre;
    }

    // OBTENGO LA DESCRIPCION
    public String getDescripcion() {
        return descripcion;
    }

    // ASIGNO LA DESCRIPCION
    public void setDescripcion(String descripcion) {

        // VALIDO QUE LA DESCRIPCION NO ESTE VACIA
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripcion es obligatoria");
        }

        this.descripcion = descripcion;
    }

    // MUESTRO LOS DATOS DE LA CATEGORIA
    @Override
    public String toString() {
        return "Categoria{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }

    // COMPARO POR ID
    @Override
    public boolean equals(Object obj) {

        // VALIDO SI ES EL MISMO OBJETO
        if (this == obj) {
            return true;
        }

        // VALIDO SI ES INSTANCIA DE CATEGORIA
        if (!(obj instanceof Categoria)) {
            return false;
        }

        Categoria otra = (Categoria) obj;

        return Objects.equals(id, otra.id);
    }

    // GENERO HASHCODE
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}


