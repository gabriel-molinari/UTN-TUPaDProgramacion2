/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package entities;

//----------IMPORTS----------
import base.Base;
import java.util.Objects;

/*
    EXPLICACION DE CLASE

    REPRESENTA UN PRODUCTO DEL SISTEMA.
*/

public class Producto extends Base {

    // NOMBRE DEL PRODUCTO
    private String nombre;

    // PRECIO DEL PRODUCTO
    private Double precio;

    // DESCRIPCION DEL PRODUCTO
    private String descripcion;

    // STOCK DISPONIBLE
    private int stock;

    // URL O NOMBRE DE IMAGEN
    private String imagen;

    // INDICA SI EL PRODUCTO ESTA DISPONIBLE
    private Boolean disponible;

    // CATEGORIA DEL PRODUCTO
    private Categoria categoria;

    // CONSTRUCTOR VACIO
    public Producto() {
        super();
    }

    // CONSTRUCTOR CON PARAMETROS
    public Producto(String nombre,
                    Double precio,
                    String descripcion,
                    int stock,
                    String imagen,
                    Boolean disponible,
                    Categoria categoria) {

        // LLAMO AL CONSTRUCTOR PADRE
        super();

        // ASIGNO LOS DATOS
        setNombre(nombre);
        setPrecio(precio);
        setDescripcion(descripcion);
        setStock(stock);
        setImagen(imagen);
        setDisponible(disponible);
        setCategoria(categoria);
    }

    // OBTENGO EL NOMBRE
    public String getNombre() {
        return nombre;
    }

    // ASIGNO EL NOMBRE
    public void setNombre(String nombre) {

        // VALIDO QUE EL NOMBRE NO ESTE VACIO
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }

        this.nombre = nombre;
    }

    // OBTENGO EL PRECIO
    public Double getPrecio() {
        return precio;
    }

    // ASIGNO EL PRECIO
    public void setPrecio(Double precio) {

        // VALIDO QUE EL PRECIO SEA MAYOR O IGUAL A 0
        if (precio == null || precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }

        this.precio = precio;
    }

    // OBTENGO LA DESCRIPCION
    public String getDescripcion() {
        return descripcion;
    }

    // ASIGNO LA DESCRIPCION
    public void setDescripcion(String descripcion) {

        // VALIDO QUE LA DESCRIPCION NO ESTE VACIA
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripcion es obligatoria");
        }

        this.descripcion = descripcion;
    }

    // OBTENGO EL STOCK
    public int getStock() {
        return stock;
    }

    // ASIGNO EL STOCK
    public void setStock(int stock) {

        // VALIDO QUE EL STOCK NO SEA NEGATIVO
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }

        this.stock = stock;
    }

    // OBTENGO LA IMAGEN
    public String getImagen() {
        return imagen;
    }

    // ASIGNO LA IMAGEN
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    // OBTENGO DISPONIBILIDAD
    public Boolean getDisponible() {
        return disponible;
    }

    // ASIGNO DISPONIBILIDAD
    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }

    // OBTENGO LA CATEGORIA
    public Categoria getCategoria() {
        return categoria;
    }

    // ASIGNO LA CATEGORIA
    public void setCategoria(Categoria categoria) {

        // VALIDO QUE EXISTA UNA CATEGORIA
        if (categoria == null) {
            throw new IllegalArgumentException("La categoria es obligatoria");
        }

        this.categoria = categoria;
    }

    // MUESTRO LOS DATOS DEL PRODUCTO
    @Override
    public String toString() {
        return "Producto{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", stock=" + stock +
                ", disponible=" + disponible +
                '}';
    }

    // COMPARO POR ID
    @Override
    public boolean equals(Object obj) {

        // VALIDO SI ES EL MISMO OBJETO
        if (this == obj) {
            return true;
        }

        // VALIDO SI ES INSTANCIA DE PRODUCTO
        if (!(obj instanceof Producto)) {
            return false;
        }

        Producto otro = (Producto) obj;

        return Objects.equals(id, otro.id);
    }

    // GENERO HASHCODE
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

}


