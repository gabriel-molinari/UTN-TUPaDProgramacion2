/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

//----------IMPORTS----------
import base.Base;
import java.util.Objects;

/*
    EXPLICACION DE CLASE

    REPRESENTA UN DETALLE DENTRO
    DE UN PEDIDO.
*/

public class DetallePedido extends Base {

    // PRODUCTO DEL DETALLE
    private Producto producto;

    // CANTIDAD SOLICITADA
    private int cantidad;

    // SUBTOTAL DEL DETALLE
    private Double subtotal;

    // CONSTRUCTOR VACIO
    public DetallePedido() {
        super();
    }

    // CONSTRUCTOR CON PARAMETROS
    public DetallePedido(Producto producto, int cantidad) {

        // LLAMO AL CONSTRUCTOR PADRE
        super();

        // ASIGNO PRODUCTO
        setProducto(producto);

        // ASIGNO CANTIDAD
        setCantidad(cantidad);

        // CALCULO EL SUBTOTAL
        calcularSubtotal();
    }

    // OBTENGO EL PRODUCTO
    public Producto getProducto() {
        return producto;
    }

    // ASIGNO EL PRODUCTO
    public void setProducto(Producto producto) {

        // VALIDO QUE EL PRODUCTO EXISTA
        if (producto == null) {
            throw new IllegalArgumentException("El producto es obligatorio");
        }

        this.producto = producto;
    }

    // OBTENGO LA CANTIDAD
    public int getCantidad() {
        return cantidad;
    }

    // ASIGNO LA CANTIDAD
    public void setCantidad(int cantidad) {

        // VALIDO QUE LA CANTIDAD SEA MAYOR A 0
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }

        this.cantidad = cantidad;
    }

    // OBTENGO EL SUBTOTAL
    public Double getSubtotal() {
        return subtotal;
    }

    // CALCULO EL SUBTOTAL
    public void calcularSubtotal() {

        // VALIDO QUE EXISTA PRODUCTO
        if (producto != null) {

            // CALCULO EL IMPORTE
            this.subtotal = producto.getPrecio() * cantidad;
        }
    }

    // MUESTRO LOS DATOS DEL DETALLE
    @Override
    public String toString() {
        return "DetallePedido{" +
                "producto=" + producto.getNombre() +
                ", cantidad=" + cantidad +
                ", subtotal=" + subtotal +
                '}';
    }

    // COMPARO POR ID
    @Override
    public boolean equals(Object obj) {

        // VALIDO SI ES EL MISMO OBJETO
        if (this == obj) {
            return true;
        }

        // VALIDO SI ES INSTANCIA DE DETALLEPEDIDO
        if (!(obj instanceof DetallePedido)) {
            return false;
        }

        DetallePedido otro = (DetallePedido) obj;

        return Objects.equals(id, otro.id);
    }

    // GENERO HASHCODE
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

}


