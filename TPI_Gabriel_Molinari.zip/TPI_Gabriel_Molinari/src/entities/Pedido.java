/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

//----------IMPORTS----------
import enums.Estado;
import enums.FormaPago;
import interfaces.Calculable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*
    EXPLICACION DE CLASE

    REPRESENTA UN PEDIDO DEL SISTEMA.
*/

public class Pedido extends base.Base implements Calculable {

    // FECHA DEL PEDIDO
    private LocalDate fecha;

    // ESTADO DEL PEDIDO
    private Estado estado;

    // TOTAL DEL PEDIDO
    private Double total;

    // FORMA DE PAGO
    private FormaPago formaPago;

    // USUARIO DEL PEDIDO
    private Usuario usuario;

    // DETALLES DEL PEDIDO
    private List<DetallePedido> detalles;

    // CONSTRUCTOR VACIO
    public Pedido() {

        // LLAMO AL CONSTRUCTOR PADRE
        super();

        // ASIGNO FECHA ACTUAL
        this.fecha = LocalDate.now();

        // INICIALIZO LA LISTA
        this.detalles = new ArrayList<>();

        // ASIGNO TOTAL INICIAL
        this.total = 0.0;
    }

    // OBTENGO LA FECHA
    public LocalDate getFecha() {
        return fecha;
    }

    // ASIGNO LA FECHA
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    // OBTENGO EL ESTADO
    public Estado getEstado() {
        return estado;
    }

    // ASIGNO EL ESTADO
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    // OBTENGO EL TOTAL
    public Double getTotal() {
        return total;
    }

    // OBTENGO LA FORMA DE PAGO
    public FormaPago getFormaPago() {
        return formaPago;
    }

    // ASIGNO LA FORMA DE PAGO
    public void setFormaPago(FormaPago formaPago) {
        this.formaPago = formaPago;
    }

    // OBTENGO EL USUARIO
    public Usuario getUsuario() {
        return usuario;
    }

    // ASIGNO EL USUARIO
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    // OBTENGO LOS DETALLES
    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    // AGREGO UN DETALLE AL PEDIDO
    public void addDetallePedido(int cantidad, Producto producto) {

        // CREO EL NUEVO DETALLE
        DetallePedido detalle = new DetallePedido(producto, cantidad);

        // AGREGO EL DETALLE A LA LISTA
        detalles.add(detalle);

        // RECALCULO EL TOTAL
        calcularTotal();
    }

    // BUSCO DETALLE POR PRODUCTO
    public DetallePedido findDetallePedidoByProducto(Producto producto) {

        // RECORRO LOS DETALLES
        for (DetallePedido detalle : detalles) {

            // VALIDO SI ES EL PRODUCTO BUSCADO
            if (detalle.getProducto().equals(producto)) {
                return detalle;
            }
        }

        return null;
    }

    // ELIMINO DETALLE POR PRODUCTO
    public void deleteDetallePedidoByProducto(Producto producto) {

        // BUSCO EL DETALLE
        DetallePedido detalle = findDetallePedidoByProducto(producto);

        // VALIDO SI EXISTE
        if (detalle != null) {
            detalles.remove(detalle);
        }

        // RECALCULO EL TOTAL
        calcularTotal();
    }

    // CALCULO EL TOTAL DEL PEDIDO
    @Override
    public Double calcularTotal() {

        // REINICIO EL TOTAL
        total = 0.0;

        // RECORRO LOS DETALLES
        for (DetallePedido detalle : detalles) {

            // ACUMULO LOS SUBTOTALES
            total += detalle.getSubtotal();
        }

        return total;
    }

    // MUESTRO LOS DATOS DEL PEDIDO
    @Override
    public String toString() {
        return "Pedido{" +
                "id=" + id +
                ", fecha=" + fecha +
                ", estado=" + estado +
                ", total=" + total +
                '}';
    }

    // COMPARO POR ID
    @Override
    public boolean equals(Object obj) {

        // VALIDO SI ES EL MISMO OBJETO
        if (this == obj) {
            return true;
        }

        // VALIDO SI ES INSTANCIA DE PEDIDO
        if (!(obj instanceof Pedido)) {
            return false;
        }

        Pedido otro = (Pedido) obj;

        return Objects.equals(id, otro.id);
    }

    // GENERO HASHCODE
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

}


