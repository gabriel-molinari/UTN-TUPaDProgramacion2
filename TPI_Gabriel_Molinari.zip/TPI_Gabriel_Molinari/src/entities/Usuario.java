/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

//----------IMPORTS----------
import enums.Rol;
import base.Base;
import java.util.Objects;

/*
    EXPLICACION DE CLASE

    REPRESENTA UN USUARIO DEL SISTEMA.
*/

public class Usuario extends Base {

    // NOMBRE DEL USUARIO
    private String nombre;

    // APELLIDO DEL USUARIO
    private String apellido;

    // MAIL DEL USUARIO
    private String mail;

    // CELULAR DEL USUARIO
    private String celular;

    // CONTRASENIA DEL USUARIO
    private String contrasenia;

    // ROL DEL USUARIO
    private Rol rol;

    // CONSTRUCTOR VACIO
    public Usuario() {
        super();
    }

    // CONSTRUCTOR CON PARAMETROS
    public Usuario(String nombre,
                   String apellido,
                   String mail,
                   String celular,
                   String contrasenia,
                   Rol rol) {

        // LLAMO AL CONSTRUCTOR PADRE
        super();

        // ASIGNO LOS DATOS
        setNombre(nombre);
        setApellido(apellido);
        setMail(mail);
        setCelular(celular);
        setContrasenia(contrasenia);
        setRol(rol);
    }

    // OBTENGO EL NOMBRE
    public String getNombre() {
        return nombre;
    }

    // ASIGNO EL NOMBRE
    public void setNombre(String nombre) {

        // VALIDO QUE EL NOMBRE NO ESTE VACIO
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }

        this.nombre = nombre;
    }

    // OBTENGO EL APELLIDO
    public String getApellido() {
        return apellido;
    }

    // ASIGNO EL APELLIDO
    public void setApellido(String apellido) {

        // VALIDO QUE EL APELLIDO NO ESTE VACIO
        if (apellido == null || apellido.trim().isEmpty()) {
            throw new IllegalArgumentException("El apellido es obligatorio");
        }

        this.apellido = apellido;
    }

    // OBTENGO EL MAIL
    public String getMail() {
        return mail;
    }

    // ASIGNO EL MAIL
    public void setMail(String mail) {

        // VALIDO QUE EL MAIL NO ESTE VACIO
        if (mail == null || mail.trim().isEmpty()) {
            throw new IllegalArgumentException("El mail es obligatorio");
        }

        this.mail = mail;
    }

    // OBTENGO EL CELULAR
    public String getCelular() {
        return celular;
    }

    // ASIGNO EL CELULAR
    public void setCelular(String celular) {

        // VALIDO QUE EL CELULAR NO ESTE VACIO
        if (celular == null || celular.trim().isEmpty()) {
            throw new IllegalArgumentException("El celular es obligatorio");
        }

        this.celular = celular;
    }

    // OBTENGO LA CONTRASENIA
    public String getContrasenia() {
        return contrasenia;
    }

    // ASIGNO LA CONTRASENIA
    public void setContrasenia(String contrasenia) {

        // VALIDO QUE LA CONTRASENIA NO ESTE VACIA
        if (contrasenia == null || contrasenia.trim().isEmpty()) {
            throw new IllegalArgumentException("La contrasenia es obligatoria");
        }

        this.contrasenia = contrasenia;
    }

    // OBTENGO EL ROL
    public Rol getRol() {
        return rol;
    }

    // ASIGNO EL ROL
    public void setRol(Rol rol) {

        // VALIDO QUE EL ROL EXISTA
        if (rol == null) {
            throw new IllegalArgumentException("El rol es obligatorio");
        }

        this.rol = rol;
    }

    // MUESTRO LOS DATOS DEL USUARIO
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", mail='" + mail + '\'' +
                ", rol=" + rol +
                '}';
    }

    // COMPARO POR ID
    @Override
    public boolean equals(Object obj) {

        // VALIDO SI ES EL MISMO OBJETO
        if (this == obj) {
            return true;
        }

        // VALIDO SI ES INSTANCIA DE USUARIO
        if (!(obj instanceof Usuario)) {
            return false;
        }

        Usuario otro = (Usuario) obj;

        return Objects.equals(id, otro.id);
    }

    // GENERO HASHCODE
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

}


