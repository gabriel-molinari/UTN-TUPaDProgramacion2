/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

//----------IMPORTS----------
import entities.Categoria;
import exception.EntidadNoEncontradaException;
import exception.CategoriaConProductosException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import service.ProductoService;

/*
    EXPLICACION DE CLASE

    ADMINISTRA LAS OPERACIONES CRUD
    DE LAS CATEGORIAS.
*/

public class CategoriaService { 
    
    // ALMACENAMIENTO EN MEMORIA
    private final Map<Long, Categoria> categorias;

    // GENERADOR DE IDS
    private Long siguienteId;   
    
    //CREO LA VARIABLE PARA EL PRODUCTOSERVICE
    private ProductoService productoService;

    // 2. CAMBIO AQUÍ: Modificás el constructor para recibir ProductoService por parámetro
    public CategoriaService() {

        // INICIALIZO EL MAPA
        this.categorias = new HashMap<>();

        // INICIALIZO EL ID
        this.siguienteId = 1L;

    }  
    
    // DECLARO LA DEPENDENCIA DE PRODUCTOSERVICE COMO ATRIBUTO PRIVADO
    public void setProductoService(ProductoService productoService) {
        this.productoService = productoService;
    }

    // CREO UNA CATEGORIA
    public Categoria crear(Categoria categoria) {

        //VALIDO QUE EL NOMBRE NO EXISTA
        for (Categoria categoriaExistente : categorias.values()) {

            if (!categoriaExistente.isEliminado()
                    && categoriaExistente.getNombre()
                            .equalsIgnoreCase(categoria.getNombre())) {

                throw new IllegalArgumentException(
                        "Ya existe una categoria con ese nombre");
            }
        }

        // ASIGNO EL ID
        categoria.setId(siguienteId++);

        // GUARDO LA CATEGORIA
        categorias.put(categoria.getId(), categoria);

        return categoria;
    }

    // LISTO CATEGORIAS ACTIVAS
    public List<Categoria> listar() {

        // CREO LISTA RESULTADO
        List<Categoria> resultado = new ArrayList<>();

        // RECORRO LAS CATEGORIAS
        for (Categoria categoria : categorias.values()) {

            // VALIDO QUE NO ESTE ELIMINADA
            if (!categoria.isEliminado()) {
                resultado.add(categoria);
            }
        }

        return resultado;
    }

    // BUSCO POR ID
    public Categoria obtenerPorId(Long id) {

        // BUSCO LA CATEGORIA
        Categoria categoria = categorias.get(id);

        // VALIDO SI EXISTE
        if (categoria == null || categoria.isEliminado()) {
            throw new EntidadNoEncontradaException("Categoria no encontrada");
        }

        return categoria;
    }

    // ACTUALIZO UNA CATEGORIA
    public void actualizar(Categoria categoria) {

        //VALIDO QUE EL NOMBRE NO PERTENEZCA A OTRA CATEGORIA
        for (Categoria categoriaExistente : categorias.values()) {

            if (!categoriaExistente.isEliminado()
                    && !categoriaExistente.getId().equals(categoria.getId())
                    && categoriaExistente.getNombre()
                            .equalsIgnoreCase(categoria.getNombre())) {

                throw new IllegalArgumentException(
                        "Ya existe una categoria con ese nombre");
            }
        }

        // VALIDO QUE EXISTA
        obtenerPorId(categoria.getId());

        // REEMPLAZO LA CATEGORIA
        categorias.put(categoria.getId(), categoria);
    }

    // ELIMINO LOGICAMENTE
    public void eliminar(Long id) {

        // VERIFICA SI TIENE PRODUCTOS ASOCIADOS
        boolean tieneProductos = productoService.listarActivos().stream()
         .anyMatch(producto -> producto.getCategoria() != null && producto.getCategoria().getId().equals(id));

        if (tieneProductos) {
            throw new CategoriaConProductosException("No se puede eliminar la categoria porque tiene productos asociados.");
        }
        // BUSCO LA CATEGORIA
        Categoria categoria = obtenerPorId(id);

        // MARCO COMO ELIMINADA
        categoria.setEliminado(true);
    }
    
    
    //LISTAR CATEGORIAS ACTIVAS    
    public List<Categoria> listarActivas() {
        return listar();
    }
}


