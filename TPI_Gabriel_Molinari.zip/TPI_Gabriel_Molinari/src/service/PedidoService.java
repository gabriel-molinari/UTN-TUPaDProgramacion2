/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package service;

//----------IMPORTS----------
import entities.DetallePedido;
import entities.Pedido;
import entities.Producto;
import entities.Usuario;
import exception.EntidadNoEncontradaException;
import exception.StockInsuficienteException;
import java.util.ArrayList;
import java.util.List;

/*
    EXPLICACION DE CLASE

    SERVICIO PARA GESTIONAR PEDIDOS
*/

public class PedidoService {

    // LISTA DE PEDIDOS
    private final List<Pedido> pedidos;

    // GENERADOR DE IDS
    private Long siguienteId;

    // DEPENDENCIAS
    private final ProductoService productoService;
    private final UsuarioService usuarioService;
    
    //CONSTRUCTOR   
    public PedidoService(ProductoService productoService, UsuarioService usuarioService) {

        this.productoService = productoService;
        this.usuarioService = usuarioService;

        pedidos = new ArrayList<>();

        siguienteId = 1L;
    }
    
    //CREAR PEDIDO    
    public Pedido crearPedido(Long usuarioId, List<DetallePedido> detalles) {

        // BUSCO USUARIO
        Usuario usuario = usuarioService.buscarPorId(usuarioId);

        // VALIDO STOCK
        for (DetallePedido detalle : detalles) {

            Producto producto =
                    productoService.obtenerPorId(
                            detalle.getProducto().getId());

            if (producto.getStock() < detalle.getCantidad()) {
                throw new StockInsuficienteException("Stock insuficiente");
            }
        }

        // DESCUENTO STOCK
        for (DetallePedido detalle : detalles) {

            productoService.reducirStock(
                    detalle.getProducto().getId(),
                    detalle.getCantidad());
        }

        // CREO PEDIDO
        Pedido pedido = new Pedido();

        // ASIGNO ID
        pedido.setId(siguienteId++);

        // ASIGNO USUARIO
        pedido.setUsuario(usuario);

        // AGREGO DETALLES
        for (DetallePedido detalle : detalles) {

            pedido.getDetalles().add(detalle);
        }

        // CALCULO TOTAL
        pedido.calcularTotal();

        // GUARDO PEDIDO
        pedidos.add(pedido);

        return pedido;
    }
    
    //BUSCAR POR ID    
    public Pedido buscarPorId(Long id) {

        // RECORRO PEDIDOS
        for (Pedido pedido : pedidos) {

            // VALIDO ID Y ELIMINADO
            if (pedido.getId().equals(id)
                    && !pedido.isEliminado()) {

                return pedido;
            }
        }

        throw new EntidadNoEncontradaException(
                "Pedido no encontrado");
    }
    
    //LISTAR ACTIVOS    
    public List<Pedido> listarActivos() {

        List<Pedido> resultado =
                new ArrayList<>();

        for (Pedido pedido : pedidos) {

            if (!pedido.isEliminado()) {
                resultado.add(pedido);
            }
        }

        return resultado;
    }

    /*
    ELIMINAR PEDIDO
    DEVUELVE STOCK Y REALIZA SOFT DELETE
    */
    public void eliminarPedido(Long id) {

        // BUSCO EL PEDIDO
        Pedido pedido = buscarPorId(id);

        // DEVUELVO EL STOCK
        for (DetallePedido detalle : pedido.getDetalles()) {

            productoService.aumentarStock(
                    detalle.getProducto().getId(),
                    detalle.getCantidad());
        }

        // MARCO EL PEDIDO COMO ELIMINADO
        pedido.setEliminado(true);
    }    
    
    //OBTENER TODOS LOS PEDIDOS ACTIVOS    
    public List<Pedido> listar() {
        return listarActivos();
    }
}


