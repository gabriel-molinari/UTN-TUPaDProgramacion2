/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

//----------IMPORTS----------
import entities.Categoria;
import entities.Producto;
import exception.EntidadNoEncontradaException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
    EXPLICACION DE CLASE

    ADMINISTRA LAS OPERACIONES CRUD
    DE PRODUCTOS.
*/

public class ProductoService {

    // ALMACENAMIENTO EN MEMORIA
    private final Map<Long, Producto> productos;

    // GENERADOR DE IDS
    private Long siguienteId;

    // SERVICE DE CATEGORIAS
    private final CategoriaService categoriaService;

    // CONSTRUCTOR
    public ProductoService(CategoriaService categoriaService) {

        // INICIALIZO EL MAPA
        productos = new HashMap<>();

        // INICIALIZO EL ID
        siguienteId = 1L;

        // GUARDO LA REFERENCIA
        this.categoriaService = categoriaService;
    }

    // CREO UN PRODUCTO
    public Producto crear(Producto producto) {

        // VALIDO QUE EXISTA LA CATEGORIA
        Categoria categoria =
                categoriaService.obtenerPorId(
                        producto.getCategoria().getId()
                );

        // ASIGNO LA CATEGORIA
        producto.setCategoria(categoria);

        // ASIGNO EL ID
        producto.setId(siguienteId++);

        // GUARDO EL PRODUCTO
        productos.put(producto.getId(), producto);

        return producto;
    }

    // LISTO PRODUCTOS ACTIVOS
    public List<Producto> listar() {

        // CREO LISTA RESULTADO
        List<Producto> resultado = new ArrayList<>();

        // RECORRO LOS PRODUCTOS
        for (Producto producto : productos.values()) {

            // VALIDO QUE NO ESTE ELIMINADO
            if (!producto.isEliminado()) {
                resultado.add(producto);
            }
        }

        return resultado;
    }

    // BUSCO POR ID
    public Producto obtenerPorId(Long id) {

        // BUSCO EL PRODUCTO
        Producto producto = productos.get(id);

        // VALIDO SI EXISTE
        if (producto == null || producto.isEliminado()) {
            throw new EntidadNoEncontradaException("Producto no encontrado");
        }

        return producto;
    }

    // ACTUALIZO PRODUCTO
    public void actualizar(Producto producto) {

        // VALIDO QUE EXISTA
        obtenerPorId(producto.getId());

        // ACTUALIZO
        productos.put(producto.getId(), producto);
    }

    // ELIMINO LOGICAMENTE
    public void eliminar(Long id) {

        // BUSCO EL PRODUCTO
        Producto producto = obtenerPorId(id);

        // MARCO COMO ELIMINADO
        producto.setEliminado(true);
    }
    
    //REDUCIR STOCK    
    public void reducirStock(Long productoId, int cantidad) {

        // BUSCO EL PRODUCTO
        Producto producto = obtenerPorId(productoId);

        // VALIDO STOCK DISPONIBLE
        if (producto.getStock() < cantidad) {
            throw new IllegalArgumentException(
                    "Stock insuficiente");
        }

        // DESCUENTO STOCK
        producto.setStock(
                producto.getStock() - cantidad);
    }

    
    //AUMENTAR STOCK    
    public void aumentarStock(Long productoId, int cantidad) {

        // BUSCO EL PRODUCTO
        Producto producto = obtenerPorId(productoId);

        // SUMO STOCK
        producto.setStock(
                producto.getStock() + cantidad);
    }
    
    //LISTAR PRODUCTOS ACTIVOS    
    public List<Producto> listarActivos() {
        return listar();
    }    
}


