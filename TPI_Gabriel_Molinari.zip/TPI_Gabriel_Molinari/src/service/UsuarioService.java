/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

//----------IMPORTS----------
import entities.Usuario;
import exception.EntidadNoEncontradaException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
    EXPLICACION DE CLASE

    SERVICIO PARA GESTIONAR USUARIOS
    IMPLEMENTA CRUD Y SOFT DELETE
*/

public class UsuarioService {

    // ALMACENAMIENTO EN MEMORIA
    private final Map<Long, Usuario> usuarios;

    // GENERADOR DE IDS
    private Long siguienteId;

    // CONSTRUCTOR
    public UsuarioService() {

        // INICIALIZO MAPA
        usuarios = new HashMap<>();

        // INICIALIZO ID
        siguienteId = 1L;
    }

    
    //CREAR USUARIO    
    public Usuario crear(Usuario usuario) {

        //VALIDO QUE EL MAIL NO EXISTA
        for (Usuario usuarioExistente : usuarios.values()) {

        if (!usuarioExistente.isEliminado() && usuarioExistente.getMail().equalsIgnoreCase(usuario.getMail())) {

           throw new IllegalArgumentException(
                    "Ya existe un usuario registrado con ese mail");
           }
        }
        
        // ASIGNO ID
        usuario.setId(siguienteId++);

        // GUARDO USUARIO
        usuarios.put(usuario.getId(), usuario);

        return usuario;
    }

    
    //BUSCAR USUARIO POR ID    
    public Usuario buscarPorId(Long id) {

        // BUSCO USUARIO
        Usuario usuario = usuarios.get(id);

        // VALIDO QUE EXISTA
        if (usuario == null || usuario.isEliminado()) {
            throw new EntidadNoEncontradaException("Usuario no encontrado");
        }

        return usuario;
    }

    
    //LISTAR USUARIOS ACTIVOS    
    public List<Usuario> listarActivos() {

        // CREO LISTA RESULTADO
        List<Usuario> resultado = new ArrayList<>();

        // RECORRO USUARIOS
        for (Usuario usuario : usuarios.values()) {

            // VALIDO QUE NO ESTE ELIMINADO
            if (!usuario.isEliminado()) {
                resultado.add(usuario);
            }
        }

        return resultado;
    }

    
    //ACTUALIZAR USUARIO
    public void actualizar(Usuario usuario) {

        // VALIDO QUE EXISTA
        buscarPorId(usuario.getId());
        
        //VALIDO QUE EL MAIL NO PERTENEZCA A OTRO USUARIO
        for (Usuario usuarioExistente : usuarios.values()) {

            if (!usuarioExistente.isEliminado()
                    && !usuarioExistente.getId().equals(usuario.getId())
                    && usuarioExistente.getMail().equalsIgnoreCase(usuario.getMail())) {

                throw new IllegalArgumentException(
                        "Ya existe un usuario registrado con ese mail");
            }
        }        
        
        // ACTUALIZO
        usuarios.put(usuario.getId(), usuario);
    }

    
    //ELIMINACION LOGICA    
    public void eliminar(Long id) {

        // BUSCO USUARIO
        Usuario usuario = buscarPorId(id);

        // MARCO ELIMINADO
        usuario.setEliminado(true);
    }
    
    
    //LISTAR USUARIOS ACTIVOS    
    public List<Usuario> listar() {
        return listarActivos();
    }
}


