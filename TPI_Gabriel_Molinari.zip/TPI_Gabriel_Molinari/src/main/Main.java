/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;

//----------IMPORTS----------
import ui.MenuConsola;

/*
    EXPLICACION DE CLASE

    CLASE PRINCIPAL
    PUNTO DE ENTRADA DEL SISTEMA
*/
public class Main {
    
    //METODO MAIN    
    public static void main(String[] args) {

        try {
            
            // CREO MENU
            MenuConsola menu = new MenuConsola();

            // INICIO MENU
            menu.iniciar();

        } catch (Exception e) {

            // MUESTRO ERROR
            System.out.println("Error: " + e.getMessage());
        }
    }
}


