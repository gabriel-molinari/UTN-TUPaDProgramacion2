/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

/*
    EXPLICACION DE CLASE

    EXCEPCION PERSONALIZADA QUE SE LANZA
    CUANDO NO HAY STOCK SUFICIENTE.
*/

public class StockInsuficienteException extends RuntimeException {

   // CONSTRUCTOR VACIO
    public StockInsuficienteException() {
        super("Stock invalido");
    }

    // CONSTRUCTOR CON MENSAJE
    public StockInsuficienteException(String mensaje) {
        super(mensaje);
    }
}


