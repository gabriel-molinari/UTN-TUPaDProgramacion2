/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

/*
    EXPLICACION DE CLASE

    EXCEPCION PERSONALIZADA QUE SE LANZA
    CUANDO UNA ENTIDAD NO EXISTE.
*/

public class EntidadNoEncontradaException extends RuntimeException {

    // CONSTRUCTOR VACIO
    public EntidadNoEncontradaException() {
        super("Entidad no encontrada");
    }

    // CONSTRUCTOR CON MENSAJE
    public EntidadNoEncontradaException(String mensaje) {
        super(mensaje);
    }
}


