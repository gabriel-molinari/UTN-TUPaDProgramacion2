/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

/*
    EXPLICACION DE CLASE

    EXCEPCION PERSONALIZADA QUE SE LANZA
    CUANDO SE QUIERE ELIMINAR UNA CATEGORIA 
    PERO TIENE PRODUCTOS ASOCIADOS.
*/

public class CategoriaConProductosException extends RuntimeException {
    public CategoriaConProductosException(String mensaje) {
        super(mensaje);
    }
}


