/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ui;

//----------IMPORTS----------
import config.AppConfig;
import entities.Categoria;
import entities.Producto;
import exception.EntidadNoEncontradaException;
import exception.CategoriaConProductosException;
import service.CategoriaService;
import service.ProductoService;
import service.UsuarioService;
import service.PedidoService;
import java.util.ArrayList;
import java.util.List;
import entities.Usuario;
import entities.DetallePedido;
import entities.Pedido;
import enums.Rol;

/*
    EXPLICACION DE CLASE

    MENU PRINCIPAL DE LA APLICACION.
    PERMITE GESTIONAR CATEGORIAS,
    PRODUCTOS, USUARIOS Y PEDIDOS.
*/

public class MenuConsola {

    // REFERENCIAS A LOS SERVICIOS
    private final CategoriaService categoriaService;
    private final ProductoService productoService;
    private final UsuarioService usuarioService;
    private final PedidoService pedidoService;

    
    //CONSTRUCTOR    
    public MenuConsola() {

        // OBTENGO LOS SERVICES
        categoriaService = AppConfig.getCategoriaService();
        productoService = AppConfig.getProductoService();
        usuarioService = AppConfig.getUsuarioService();
        pedidoService = AppConfig.getPedidoService();
    }

    
    //INICIAR MENU    
    public void iniciar() {

        // VARIABLE DE CONTROL
        boolean salir = false;

        while (!salir) {

            mostrarMenuPrincipal();

            int opcion = InputHelper.leerOpcion(1, 5, "Seleccione una opcion: ");

            switch (opcion) {

                case 1 -> gestionarCategorias();
                case 2 -> gestionarProductos();
                case 3 -> gestionarUsuarios();
                case 4 -> gestionarPedidos();
                case 5 -> {
                    salir = true;
                    System.out.println("Fin del programa");
                }
            }
        }

        InputHelper.cerrar();
    }

    
    //MOSTRAR MENU PRINCIPAL    
    private void mostrarMenuPrincipal() {

        System.out.println();
        System.out.println("========== MENU ==========");
        System.out.println("1 - Categorias");
        System.out.println("2 - Productos");
        System.out.println("3 - Usuarios");
        System.out.println("4 - Pedidos");
        System.out.println("5 - Salir");
    }
    
    // MENU DE CATEGORIAS    
    private void gestionarCategorias() {

        boolean volver = false;

        while (!volver) {

            System.out.println();
            System.out.println("----- CATEGORIAS -----");
            System.out.println("1 - Listar");
            System.out.println("2 - Crear");
            System.out.println("3 - Actualizar");
            System.out.println("4 - Eliminar");
            System.out.println("5 - Volver");

            int opcion = InputHelper.leerOpcion( 1, 5, "Seleccione una opcion: ");

            switch (opcion) {

                case 1 -> listarCategorias();
                case 2 -> crearCategoria();
                case 3 -> actualizarCategoria();
                case 4 -> eliminarCategoria();
                case 5 -> volver = true;
            }
        }
    }
    
    //SOLICITO CONFIRMACION S O N
    private boolean confirmarOperacion(String mensaje) {

      String respuesta = InputHelper.leerStringNoVacio(mensaje + " (S/N): ");
      return respuesta.equalsIgnoreCase("S");
    }
    
    //LISTAR CATEGORIAS    
    private void listarCategorias() {

        System.out.println();
        
         List<Categoria> categorias = categoriaService.listar();

        //VALIDO SI NO HAY CATEGORIAS
        if (categorias.isEmpty()) {

            System.out.println("No hay categorias cargadas");
            return;
        }

        for (Categoria categoria :
                categoriaService.listar()) {

            System.out.println(categoria);
        }
    }
    
    //CREAR CATEGORIA    
    private void crearCategoria() {

        try {
            // SOLICITO NOMBRE
            String nombre = InputHelper.leerStringNoVacio("Nombre: ");

            // SOLICITO DESCRIPCION
            String descripcion = InputHelper.leerStringNoVacio("Descripcion: ");

            // CREO CATEGORIA
            Categoria categoria = new Categoria(nombre, descripcion);

            // GUARDO
            categoriaService.crear(categoria);

            System.out.println("Categoria creada correctamente");
        } catch (IllegalArgumentException e) {

            System.out.println(
                    "Error: " + e.getMessage());
        }
    }
    
    //ACTUALIZAR CATEGORIA
    private void actualizarCategoria() {

        try {

            //VALIDO SI HAY CATEGORIAS
            if (categoriaService.listar().isEmpty()) {

                System.out.println("No hay categorias cargadas");
                return;
            }

            //LISTO CATEGORIAS
            listarCategorias();

            //SOLICITO ID
            Long id = (long) InputHelper.leerIntPositivo("Id categoria: ");

            //BUSCO CATEGORIA
            Categoria categoria =
                    categoriaService.obtenerPorId(id);

            //SOLICITO NUEVOS DATOS
            String nombre = InputHelper.leerStringNoVacio("Nuevo nombre: ");

            String descripcion =
                    InputHelper.leerStringNoVacio("Nueva descripcion: ");

            //SOLICITO CONFIRMACION
            if (!confirmarOperacion("Confirma actualizacion")) {
                System.out.println("Operacion cancelada");
                return;
            }

            //ACTUALIZO DATOS
            categoria.setNombre(nombre);
            categoria.setDescripcion(descripcion);

            //GUARDO CAMBIOS
            categoriaService.actualizar(categoria);

            System.out.println("Categoria actualizada correctamente");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(
                    e.getMessage());
        }
    }
    
    //ELIMINAR CATEGORIA    
    private void eliminarCategoria() {

        //VALIDO SI HAY CATEGORIAS
        if (categoriaService.listar().isEmpty()) {

            System.out.println(
                    "No hay categorias cargadas");

            return;
        }
    
        listarCategorias();

        Long id = (long) InputHelper.leerIntPositivo("Id de categoria: ");
        
        //SOLICITO CONFIRMACION
        if (!confirmarOperacion("Confirma eliminacion")){

            System.out.println("Operacion cancelada");
            return;
        }

        try {
            categoriaService.eliminar(id);

            System.out.println("Categoria eliminada");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(e.getMessage());        
        } catch (CategoriaConProductosException e) {
            
            System.out.println("Error: " + e.getMessage());
        }
    }

    
    //MENU DE PRODUCTOS    
    private void gestionarProductos() {

        boolean volver = false;

        while (!volver) {

            System.out.println();
            System.out.println("----- PRODUCTOS -----");
            System.out.println("1 - Listar");
            System.out.println("2 - Crear");
            System.out.println("3 - Actualizar");
            System.out.println("4 - Eliminar");
            System.out.println("5 - Volver");

            int opcion = InputHelper.leerOpcion(1, 5, "Seleccione una opcion: ");

            switch (opcion) {

                case 1 -> listarProductos();
                case 2 -> crearProducto();
                case 3 -> actualizarProducto();
                case 4 -> eliminarProducto();
                case 5 -> volver = true;
            }
        }
    }

    //LISTAR PRODUCTOS    
    private void listarProductos() {

        System.out.println();
        
        List<Producto> productos = productoService.listar();

        //VALIDO SI NO HAY PRODUCTOS
        if (productos.isEmpty()) {

            System.out.println("No hay productos cargados");
            return;
        }

        for (Producto producto :
                productoService.listar()) {

            System.out.println(producto);
        }
    }
    
    //CREAR PRODUCTO    
    private void crearProducto() {

        //VALIDO SI HAY CATEGORIAS
        if (categoriaService.listar().isEmpty()) {

            System.out.println("No hay categorias cargadas");
            return;
        }

        // SOLICITO DATOS
        String nombre = InputHelper.leerStringNoVacio("Nombre: ");

        double precio = InputHelper.leerDoubleNoNegativo("Precio: ");

        String descripcion = InputHelper.leerStringNoVacio("Descripcion: ");

        int stock = InputHelper.leerIntPositivo("Stock: ");

        String imagen = InputHelper.leerLinea("Imagen: ");

        // LISTO CATEGORIAS
        listarCategorias();

        Long categoriaId = (long) InputHelper.leerIntPositivo("Id categoria: ");

        Categoria categoria = categoriaService.obtenerPorId(categoriaId);

        // CREO PRODUCTO
        Producto producto =
                new Producto(
                        nombre,
                        precio,
                        descripcion,
                        stock,
                        imagen,
                        true,
                        categoria);

        // GUARDO
        productoService.crear(producto);

        System.out.println(
                "Producto creado correctamente");
    }
    
    //ACTUALIZAR PRODUCTO    
    private void actualizarProducto() {

        try {
            
            //VALIDO SI HAY PRODUCTOS
            if (productoService.listar().isEmpty()) {

                System.out.println("No hay productos cargados");
                return;
            }

            // LISTO PRODUCTOS
            listarProductos();

            // SOLICITO ID
            Long id = (long) InputHelper.leerIntPositivo("Id producto: ");

            // BUSCO PRODUCTO
            Producto producto = productoService.obtenerPorId(id);
            
            // SOLICITO NUEVOS DATOS
            String nombre = InputHelper.leerStringNoVacio("Nuevo nombre: ");

            double precio = InputHelper.leerDoubleNoNegativo("Nuevo precio: ");

            String descripcion = InputHelper.leerStringNoVacio("Nueva descripcion: ");

            int stock = InputHelper.leerIntPositivo("Nuevo stock: ");

            String imagen = InputHelper.leerLinea("Nueva imagen: ");
            
            //SOLICITO CONFIRMACION
            if (!confirmarOperacion("Confirma actualizacion")) {

                System.out.println("Operacion cancelada");
                return;
            }

            // ACTUALIZO DATOS
            producto.setNombre(nombre);
            producto.setPrecio(precio);
            producto.setDescripcion(descripcion);
            producto.setStock(stock);
            producto.setImagen(imagen);

            // GUARDO CAMBIOS
            productoService.actualizar(producto);

            System.out.println(
                    "Producto actualizado correctamente");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(
                    e.getMessage());
        }
    }
    
    //ELIMINAR PRODUCTO    
    private void eliminarProducto() {  
      
        //VALIDO SI HAY PRODUCTOS
        if (productoService.listar().isEmpty()) {

            System.out.println("No hay productos cargados");
            return;
        }
    
        try {

            listarProductos();

            Long id = (long) InputHelper.leerIntPositivo("Id producto: ");
            
             //SOLICITO CONFIRMACION
            if (!confirmarOperacion("Confirma eliminacion")){

                System.out.println("Operacion cancelada");
                return;
            }

            productoService.eliminar(id);

            System.out.println("Producto eliminado");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(e.getMessage());
        }
    }
    
    //MENU DE USUARIOS    
    private void gestionarUsuarios() {

        boolean volver = false;

        while (!volver) {

            System.out.println();
            System.out.println("----- USUARIOS -----");
            System.out.println("1 - Listar");
            System.out.println("2 - Crear");
            System.out.println("3 - Actualizar");
            System.out.println("4 - Eliminar");
            System.out.println("5 - Volver");

            int opcion =
                    InputHelper.leerOpcion(
                            1,
                            5,
                            "Seleccione una opcion: ");

            switch (opcion) {

                case 1 -> listarUsuarios();
                case 2 -> crearUsuario();
                case 3 -> actualizarUsuario();
                case 4 -> eliminarUsuario();
                case 5 -> volver = true;
            }
        }
    }
    
    //LISTAR USUARIOS    
    private void listarUsuarios() {

         List<Usuario> usuarios = usuarioService.listar();

        //VALIDO SI NO HAY USUARIOS
        if (usuarios.isEmpty()) {
            
            System.out.println("No hay usuarios cargados");
            return;
        }
    
        for (var usuario :
                usuarioService.listar()) {

            System.out.println(usuario);
        }
    }
    
    //CREAR USUARIO    
    private void crearUsuario() {
    try {
        String nombre = InputHelper.leerStringNoVacio("Nombre: ");

        String apellido = InputHelper.leerStringNoVacio("Apellido: ");

        String mail = InputHelper.leerStringNoVacio("Mail: ");

        String celular = InputHelper.leerStringNoVacio("Celular: ");

        String contrasenia = InputHelper.leerStringNoVacio("Contrasenia: ");

        Usuario usuario =
                new Usuario(
                        nombre,
                        apellido,
                        mail,
                        celular,
                        contrasenia,
                        Rol.USUARIO);

        usuarioService.crear(usuario);

        System.out.println("Usuario creado correctamente");
     
        } catch (IllegalArgumentException e) {

            System.out.println("Error: " + e.getMessage());
        }
    }
    
    //ACTUALIZAR USUARIO
    private void actualizarUsuario() {

        try {
            
            //VALIDO SI HAY USUARIOS
            if (usuarioService.listar().isEmpty()) {

                System.out.println("No hay usuarios cargados");
                return;
            }

            //LISTO USUARIOS
            listarUsuarios();

            //SOLICITO ID
            Long id =
                    (long) InputHelper.leerIntPositivo(
                            "Id usuario: ");

            //BUSCO USUARIO
            Usuario usuario =
                    usuarioService.buscarPorId(id);

            //SOLICITO NUEVOS DATOS
            String nombre =
                    InputHelper.leerStringNoVacio(
                            "Nuevo nombre: ");

            String apellido =
                    InputHelper.leerStringNoVacio(
                            "Nuevo apellido: ");

            String mail =
                    InputHelper.leerStringNoVacio(
                            "Nuevo mail: ");

            String celular =
                    InputHelper.leerStringNoVacio(
                            "Nuevo celular: ");

            String contrasenia =
                    InputHelper.leerStringNoVacio(
                            "Nueva contrasenia: ");

            //SOLICITO CONFIRMACION
            if (!confirmarOperacion("Confirma actualizacion")) {

                System.out.println("Operacion cancelada");
                return;
            }

            //ACTUALIZO DATOS
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setMail(mail);
            usuario.setCelular(celular);
            usuario.setContrasenia(contrasenia);

            //GUARDO CAMBIOS
            usuarioService.actualizar(usuario);

            System.out.println(
                    "Usuario actualizado correctamente");

        } catch (Exception e) {

            System.out.println(
                    "Error: " + e.getMessage());
        }
    }
    
    //ELIMINAR USUARIO    
    private void eliminarUsuario() {

        //VALIDO SI HAY USUARIOS
        if (usuarioService.listar().isEmpty()) {

            System.out.println("No hay usuarios cargados");
            return;
        }     

        try {

            listarUsuarios();

            Long id =
                    (long) InputHelper.leerIntPositivo(
                            "Id usuario: ");

            //SOLICITO CONFIRMACION
           if (!confirmarOperacion("Confirma eliminacion")){

                System.out.println("Operacion cancelada");
                return;
            }
        
            usuarioService.eliminar(id);

            System.out.println(
                    "Usuario eliminado");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(
                    e.getMessage());
        }
    }
    
    //MENU DE PEDIDOS    
    private void gestionarPedidos() {

        boolean volver = false;

        while (!volver) {

            System.out.println();
            System.out.println("----- PEDIDOS -----");
            System.out.println("1 - Listar");
            System.out.println("2 - Crear");
            System.out.println("3 - Eliminar");
            System.out.println("4 - Volver");

            int opcion =
                    InputHelper.leerOpcion(
                            1,
                            4,
                            "Seleccione una opcion: ");

            switch (opcion) {

                case 1 -> listarPedidos();
                case 2 -> crearPedido();
                case 3 -> eliminarPedido();
                case 4 -> volver = true;
            }
        }
    }
    
    //LISTAR PEDIDOS    
    private void listarPedidos() {

        List<Pedido> pedidos =  pedidoService.listar();

        //VALIDO SI NO HAY PEDIDOS
        if (pedidos.isEmpty()) {

            System.out.println("No hay pedidos cargados");
            return;
        }
    
        for (var pedido :
                pedidoService.listar()) {

            System.out.println(pedido);
        }
    }
    
    //CREAR PEDIDO    
    private void crearPedido() {

        try {
            
            //VALIDO SI HAY USUARIOS
            if (usuarioService.listar().isEmpty()) {

                System.out.println("No hay usuarios cargados");
                return;
            }

            listarUsuarios();

            Long usuarioId = (long) InputHelper.leerIntPositivo("Id usuario: ");

            List<DetallePedido> detalles = new ArrayList<>();

            boolean agregarMas = true;

            while (agregarMas) {
                
                //VALIDO SI HAY PRODUCTOS
                if (productoService.listar().isEmpty()) {

                    System.out.println("No hay productos cargados");
                    return;
                }

                listarProductos();

                Long productoId = (long) InputHelper.leerIntPositivo("Id producto: ");

                int cantidad = InputHelper.leerIntPositivo("Cantidad: ");

                Producto producto = productoService.obtenerPorId(productoId);

                DetallePedido detalle = new DetallePedido(producto,cantidad);

                detalles.add(detalle);

                int opcion =
                        InputHelper.leerOpcion(
                                1,
                                2,
                                "1-Seguir 2-Terminar: ");

                agregarMas = opcion == 1;
            }

            pedidoService.crearPedido(
                    usuarioId,
                    detalles);

            System.out.println(
                    "Pedido creado correctamente");

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
    
    //ELIMINAR PEDIDO    
    private void eliminarPedido() {
        
        //VALIDO SI HAY PEDIDOS
        if (pedidoService.listar().isEmpty()) {

            System.out.println("No hay pedidos cargados");
            return;
        }
        
        try {

            listarPedidos();

            Long id = (long) InputHelper.leerIntPositivo("Id pedido: ");
            
            //SOLICITO CONFIRMACION
            if (!confirmarOperacion("Confirma eliminacion")){

                System.out.println("Operacion cancelada");
                return;
            }

            pedidoService.eliminarPedido(id);

            System.out.println("Pedido eliminado");

        } catch (EntidadNoEncontradaException e) {

            System.out.println(e.getMessage());
        }
    }
}


