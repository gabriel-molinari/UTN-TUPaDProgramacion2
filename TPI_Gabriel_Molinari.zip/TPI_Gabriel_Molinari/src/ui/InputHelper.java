/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ui;

//----------IMPORTS----------
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/*
  EXPLICACION DE CLASE
  HELPER ESTATICO PARA LEER ENTRADAS DESDE CONSOLA.
  PROVEE METODOS SEGUROS Y REUTILIZABLES PARA LEER STRINGS, ENTEROS,
  DOUBLES, OPCIONES, SI/NO Y OTROS TIPOS COMUNES. MANEJA ERRORES DE
  FORMATO Y PROTEGE EL ACCESO AL SCANNER.
  CREADO PARA EL (UI).
*/

public final class InputHelper {

    //DECLARO SCANNER PARA LEER DESDE SYSTEM IN
    private static final Scanner SCANNER = new Scanner(System.in);

    //CONSTRUCTOR PRIVADO PARA EVITAR INSTANCIACION
    private InputHelper() { }

    //LEO UNA LINEA COMPLETA COMO STRING
    public static String leerLinea(String prompt) {
        //MUESTRO MENSAJE SI VIENE
        if (prompt != null && !prompt.isEmpty()) {
            System.out.print(prompt);
        }
        try {
            return SCANNER.nextLine();
        } catch (NoSuchElementException | IllegalStateException e) {
            throw new RuntimeException("Error leyendo de la consola", e);
        }
    }

    //LEO UN STRING NO VACIO (TRIM). REPITE HASTA QUE EL USUARIO INGRESE VALOR VALIDO.
    public static String leerStringNoVacio(String prompt) {
        //VALIDO QUE EL STRING NO SEA NULO NI VACIO
        while (true) {
            String linea = leerLinea(prompt);
            if (linea != null && !linea.trim().isEmpty()) {
                return linea.trim();
            }
            System.out.println("Valor invalido. Intente de nuevo.");
        }
    }

    //LEO UN ENTERO
    public static int leerInt(String prompt) {
        //INTENTO LEER UN ENTERO Y MANEJO ERRORES DE FORMATO
        while (true) {
            if (prompt != null && !prompt.isEmpty()) {
                System.out.print(prompt);
            }
            try {
                int val = SCANNER.nextInt();
                SCANNER.nextLine(); //CONSUMO EL SALTO DE LINEA
                return val;
            } catch (InputMismatchException e) {
                SCANNER.nextLine(); //DESCARTO TOKEN INVALIDO
                System.out.println("Entrada invalida. Debe ingresar un numero entero.");
            } catch (NoSuchElementException | IllegalStateException e) {
                throw new RuntimeException("Error leyendo de la consola", e);
            }
        }
    }

    //LEO UN ENTERO MAYOR A 0. REPITE HASTA QUE EL USUARIO INGRESE VALOR VALIDO.
    public static int leerIntPositivo(String prompt) {
        //VALIDO QUE EL ENTERO SEA MAYOR A 0
        while (true) {
            int val = leerInt(prompt);
            if (val > 0) {
                return val;
            }
            System.out.println("El valor debe ser mayor a 0. Intente de nuevo.");
        }
    }

    //LEO UN DOUBLE
    public static double leerDouble(String prompt) {
        //INTENTO LEER UN DOUBLE Y MANEJO ERRORES DE FORMATO
        while (true) {
            if (prompt != null && !prompt.isEmpty()) {
                System.out.print(prompt);
            }
            try {
                double val = SCANNER.nextDouble();
                SCANNER.nextLine(); //CONSUMO EL SALTO DE LINEA
                return val;
            } catch (InputMismatchException e) {
                SCANNER.nextLine(); //DESCARTO TOKEN INVALIDO
                System.out.println("Entrada invalida. Debe ingresar un numero decimal.");
            } catch (NoSuchElementException | IllegalStateException e) {
                throw new RuntimeException("Error leyendo de la consola", e);
            }
        }
    }

    //LEO UN DOUBLE NO NEGATIVO
    public static double leerDoubleNoNegativo(String prompt) {
        //VALIDO QUE EL DOUBLE NO SEA NEGATIVO
        while (true) {
            double val = leerDouble(prompt);
            if (!Double.isNaN(val) && val >= 0.0) {
                return val;
            }
            System.out.println("El valor debe ser mayor o igual a 0. Intente de nuevo.");
        }
    }

    //LEO UNA OPCION ENTRE VARIAS (POR INDICE). REPITE HASTA VALOR VALIDO.
    public static int leerOpcion(int minIncl, int maxIncl, String prompt) {
        //VALIDO QUE LOS LIMITES SEAN CONSISTENTES
        if (minIncl > maxIncl) {
            throw new IllegalArgumentException("Limites invalidos");
        }
        while (true) {
            int val = leerInt(prompt);
            if (val >= minIncl && val <= maxIncl) {
                return val;
            }
            System.out.println("Opcion invalida. Ingrese un numero entre " + minIncl + " y " + maxIncl + ".");
        }
    }

    //CIERRO EL SCANNER (LO USO AL FINAL DE LA APLICACION)
    public static void cerrar() {
        //CIERRO EL SCANNER SI ESTA ABIERTO
        try {
            SCANNER.close();
        } catch (IllegalStateException e) {
            //IGNORO SI YA ESTA CERRADO
        }
    }
}


