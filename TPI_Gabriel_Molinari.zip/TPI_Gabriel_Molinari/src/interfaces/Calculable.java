/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/*
    EXPLICACION DE CLASE

    DEFINE EL COMPORTAMIENTO NECESARIO
    PARA CALCULAR TOTALES.
*/

public interface Calculable {
    // CALCULO EL TOTAL
    Double calcularTotal();
}


