/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enums;

/*
    EXPLICACION DEL CLASE

    DEFINE LAS FORMAS DE PAGO
    DISPONIBLES EN EL SISTEMA.
*/

public enum FormaPago {
    TARJETA,
    TRANSFERENCIA,
    EFECTIVO
}


