/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enums;

/*
    EXPLICACION DEL CLASE

    DEFINE LOS ROLES DISPONIBLES
    PARA LOS USUARIOS DEL SISTEMA.
*/

public enum Rol {
    ADMIN,
    USUARIO
}


