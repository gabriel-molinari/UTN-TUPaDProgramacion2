/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package base;

//----------IMPORTS----------
import java.time.LocalDateTime;

/*
    EXPLICACION DE CLASE

    CLASE ABSTRACTA BASE QUE CONTIENE LOS ATRIBUTOS
    COMUNES A TODAS LAS ENTIDADES DEL SISTEMA.
*/

public abstract class Base {

    // IDENTIFICADOR UNICO DE LA ENTIDAD
    protected Long id;

    // INDICA SI LA ENTIDAD FUE ELIMINADA LOGICAMENTE
    protected boolean eliminado;

    // FECHA Y HORA DE CREACION
    protected LocalDateTime createdAt;

    // CONSTRUCTOR VACIO
    public Base() {

        // INICIALIZO EL ESTADO DE ELIMINACION
        this.eliminado = false;

        // ASIGNO FECHA DE CREACION
        this.createdAt = LocalDateTime.now();
    }

    // OBTENGO EL ID
    public Long getId() {
        return id;
    }

    // ASIGNO EL ID
    public void setId(Long id) {

        // VALIDO QUE EL ID SEA MAYOR A 0
        if (id != null && id <= 0) {
            throw new IllegalArgumentException("El id debe ser mayor a 0");
        }

        this.id = id;
    }

    // OBTENGO EL ESTADO DE ELIMINACION
    public boolean isEliminado() {
        return eliminado;
    }

    // ASIGNO EL ESTADO DE ELIMINACION
    public void setEliminado(boolean eliminado) {
        this.eliminado = eliminado;
    }

    // OBTENGO LA FECHA DE CREACION
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    // ASIGNO LA FECHA DE CREACION
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

}


