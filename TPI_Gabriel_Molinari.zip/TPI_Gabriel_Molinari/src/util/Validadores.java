/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/*
    EXPLICACION DE CLASE

    CONTIENE VALIDACIONES GENERALES
    UTILIZADAS EN TODA LA APLICACION.
*/

public final class Validadores {

    // EVITO INSTANCIAR LA CLASE
    private Validadores() {
    }
    
    //VALIDO QUE UN TEXTO NO ESTE VACIO    
    public static void validarTexto(String texto) {

        // VALIDO QUE NO SEA NULO NI VACIO
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El texto es obligatorio");
        }
    }
    
    //VALIDO QUE UN ID SEA MAYOR A 0    
    public static void validarId(Long id) {

        // VALIDO QUE EL ID SEA MAYOR A 0
        if (id == null || id <= 0) {
            throw new IllegalArgumentException(
                    "Id invalido");
        }
    }
    
    //VALIDO PRECIO    
    public static void validarPrecio(Double precio) {

        // VALIDO QUE NO SEA NEGATIVO
        if (precio == null || precio < 0) {
            throw new IllegalArgumentException(
                    "Precio invalido");
        }
    }
    
    //VALIDO STOCK    
    public static void validarStock(int stock) {

        // VALIDO QUE NO SEA NEGATIVO
        if (stock < 0) {
            throw new IllegalArgumentException(
                    "Stock invalido");
        }
    }
    
    //VALIDO CANTIDAD    
    public static void validarCantidad(int cantidad) {

        // VALIDO QUE SEA MAYOR A 0
        if (cantidad <= 0) {
            throw new IllegalArgumentException(
                    "Cantidad invalida");
        }
    }
    
    //VALIDO QUE EL OBJETO EXISTA    
    public static void validarNoNulo(
            Object objeto,
            String mensaje) {

        // VALIDO QUE EL OBJETO NO SEA NULO
        if (objeto == null) {
            throw new IllegalArgumentException(
                    mensaje);
        }
    }
}


