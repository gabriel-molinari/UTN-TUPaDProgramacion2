/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package config;

//----------IMPORTS----------
import service.CategoriaService;
import service.ProductoService;
import service.UsuarioService;
import service.PedidoService;
import java.util.ArrayList;
import java.util.List;
import entities.Categoria;
import entities.Producto;
import entities.Usuario;
import entities.DetallePedido;
import enums.Rol;

/*
    EXPLICACION DE CLASE

    CENTRALIZA LA CREACION DE LOS
    SERVICES DE LA APLICACION.
*/

public class AppConfig {

    // INSTANCIA DE CATEGORIAS
    private static final CategoriaService categoriaService = new CategoriaService();

    // INSTANCIA DE PRODUCTOS
    private static ProductoService productoService = new ProductoService(categoriaService);

    // INSTANCIA DE USUARIOS
    private static final UsuarioService usuarioService = new UsuarioService();

    // INSTANCIA DE PEDIDOS
    private static final PedidoService pedidoService =
            new PedidoService(productoService, usuarioService);
    
    // CARGO DATOS INICIALES
    // BLOQUE ESTATICO PARA EJECUTAR LA CARGA AL INICIAR LA APLICACION
    static {
        categoriaService.setProductoService(productoService);
        cargarDatosIniciales();
    }

    // OBTENGO SERVICE DE CATEGORIAS
    public static CategoriaService getCategoriaService() {
        return categoriaService;
    }

    // OBTENGO SERVICE DE PRODUCTOS
    public static ProductoService getProductoService() {
        return productoService;
    }

    // OBTENGO SERVICE DE USUARIOS
    public static UsuarioService getUsuarioService() {
        return usuarioService;
    }

    // OBTENGO SERVICE DE PEDIDOS
    public static PedidoService getPedidoService() {
        return pedidoService;
    }
    
    /*
    CARGAR DATOS INICIALES
    CREA CATEGORIAS, PRODUCTOS Y USUARIOS
    PARA PROBAR EL SISTEMA
    */
    private static void cargarDatosIniciales() {

        // CREO CATEGORIAS
        Categoria bebidas = new Categoria("Bebidas", "Productos para beber");
        Categoria snacks = new Categoria("Dulces", "Productos dulces para comer");

        categoriaService.crear(bebidas);
        categoriaService.crear(snacks);

        // CREO PRODUCTOS
        Producto agua = new Producto("Agua", 500.0, "Botella de agua", 100, "agua.jpg", true, bebidas);
        Producto gaseosa = new Producto("Gaseosa", 1200.0, "Gaseosa cola", 50, "gaseosa.jpg", true, bebidas);
        Producto galletitas = new Producto("Galletitas", 900.0, "Paquete de galletitas", 75, "galletitas.jpg", true, snacks);

        productoService.crear(agua);
        productoService.crear(gaseosa);
        productoService.crear(galletitas);

        // CREO USUARIO COMUN
        Usuario usuario = new Usuario("Gabriel", "Perez", "gabriel@mail.com", "1122334455", "1234", Rol.USUARIO);

        // CREO ADMIN
        Usuario admin = new Usuario("Admin", "Sistema", "admin@mail.com", "000000000", "admin", Rol.ADMIN);
        
        usuarioService.crear(usuario);
        usuarioService.crear(admin);
    
    
        // CREO DETALLES
        DetallePedido detalle1 = new DetallePedido(agua,2);
        DetallePedido detalle2 = new DetallePedido(galletitas,1);

        // CREO LISTA DE DETALLES
        List<DetallePedido> detalles = new ArrayList<>();

        detalles.add(detalle1);
        detalles.add(detalle2);

        // CREO PEDIDO
        pedidoService.crearPedido(usuario.getId(), detalles);
    
    }
}


